import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import type { Session, Player, InsertPlayer } from "@shared/schema";

export default function JoinPage() {
  const { sessionId } = useParams();
  const [, setLocation] = useLocation();
  const [playerName, setPlayerName] = useState("");
  const { toast } = useToast();

  const { data: session, isLoading: sessionLoading } = useQuery<Session>({
    queryKey: ["/api/sessions", sessionId],
    enabled: !!sessionId,
  });

  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ["/api/sessions", sessionId, "players"],
    enabled: !!sessionId,
    refetchInterval: 2000, // Poll every 2 seconds for real-time updates
  });

  const addPlayerMutation = useMutation({
    mutationFn: async (playerData: InsertPlayer) => {
      const response = await apiRequest("POST", `/api/sessions/${sessionId}/players`, playerData);
      return response.json() as Promise<Player>;
    },
    onSuccess: (player) => {
      toast({
        title: "Welcome!",
        description: `You are player #${String(player.playerNumber).padStart(3, '0')}`,
      });
      setLocation(`/vote/${sessionId}/${player.id}`);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to join session. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleJoin = () => {
    if (!playerName.trim()) {
      toast({
        title: "Error",
        description: "Please enter your name",
        variant: "destructive",
      });
      return;
    }

    addPlayerMutation.mutate({
      sessionId: sessionId!,
      name: playerName.trim(),
    });
  };

  if (sessionLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-squid-dark">
        <div className="text-squid-teal font-orbitron text-xl">Loading session...</div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-squid-dark">
        <div className="text-center">
          <div className="text-squid-red font-orbitron text-2xl mb-4">Session Not Found</div>
          <Button onClick={() => setLocation("/")} className="bg-squid-pink hover:bg-squid-pink-light">
            Create New Session
          </Button>
        </div>
      </div>
    );
  }

  const nextPlayerNumber = String(players.length + 1).padStart(3, '0');

  return (
    <div className="min-h-screen flex items-center justify-center relative bg-squid-dark">
      <div className="absolute inset-0 pink-glow"></div>
      <div className="absolute inset-0 bg-gradient-to-br from-squid-dark via-squid-dark-light to-squid-dark opacity-90"></div>
      
      <div className="relative z-10 max-w-xl mx-auto px-6 text-center">
        <div className="mb-8">
          <h1 className="font-orbitron text-4xl md:text-6xl font-black text-squid-pink mb-4">
            PLAYER ENTRY
          </h1>
          <div className="w-24 h-1 bg-squid-teal mx-auto"></div>
        </div>

        <div className="bg-squid-dark-light/80 backdrop-blur-sm border border-squid-pink/30 rounded-2xl p-8">
          <div className="mb-8">
            <div className="w-24 h-24 bg-squid-green rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-white font-orbitron font-bold text-lg">{nextPlayerNumber}</span>
            </div>
            <p className="text-squid-teal font-orbitron">PLAYER NUMBER ASSIGNED</p>
          </div>

          <div className="mb-6">
            <h3 className="text-squid-teal font-orbitron font-bold text-lg mb-4">VOTING TOPIC:</h3>
            <p className="text-white text-lg">{session.question}</p>
          </div>

          <div className="space-y-6">
            <div>
              <Label className="block text-sm font-medium mb-3 text-squid-pink">PLAYER NAME</Label>
              <Input
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                placeholder="Enter your name..."
                className="w-full px-4 py-4 bg-squid-dark border-2 border-squid-teal/50 rounded-lg font-orbitron text-white placeholder-gray-400 focus:border-squid-teal focus:outline-none focus:ring-2 focus:ring-squid-teal/50"
                onKeyPress={(e) => e.key === 'Enter' && handleJoin()}
              />
            </div>
          </div>

          <Button
            onClick={handleJoin}
            disabled={addPlayerMutation.isPending}
            className="w-full mt-8 bg-squid-teal hover:bg-cyan-400 text-squid-dark font-orbitron font-bold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105"
          >
            {addPlayerMutation.isPending ? "JOINING..." : "JOIN VOTING"}
          </Button>
        </div>
        
        {/* Attribution */}
        <div className="mt-16 text-center border-t border-squid-teal/20 pt-8">
          <p className="text-gray-400 text-sm font-inter">
            Made by <span className="text-squid-teal font-semibold">Yuvraj Singh</span>
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Check me out on{" "}
            <a 
              href="https://linktr.ee/curioboxys" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-squid-pink hover:text-squid-pink-light transition-colors underline"
            >
              https://linktr.ee/curioboxys
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

import { Player } from "@shared/schema";

interface SquidGameAvatarProps {
  player: Player;
  size?: "sm" | "md" | "lg";
}

export function SquidGameAvatar({ player, size = "md" }: SquidGameAvatarProps) {
  const sizeClasses = {
    sm: "w-12 h-12 text-xs",
    md: "w-16 h-16 text-sm", 
    lg: "w-20 h-20 text-base"
  };

  // Create an SVG-based Squid Game player avatar
  const SquidGamePlayerSVG = () => (
    <svg viewBox="0 0 120 120" className="w-full h-full">
      <defs>
        <linearGradient id="tracksuit" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4ade80"/>
          <stop offset="50%" stopColor="#22c55e"/>
          <stop offset="100%" stopColor="#16a34a"/>
        </linearGradient>
        <linearGradient id="face" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fbbf24"/>
          <stop offset="100%" stopColor="#f59e0b"/>
        </linearGradient>
      </defs>
      
      {/* Shadow */}
      <ellipse cx="60" cy="115" rx="45" ry="8" fill="rgba(0,0,0,0.2)"/>
      
      {/* Body (tracksuit) */}
      <ellipse cx="60" cy="80" rx="25" ry="35" fill="url(#tracksuit)" stroke="#15803d" strokeWidth="2"/>
      
      {/* Head */}
      <circle cx="60" cy="40" r="22" fill="url(#face)" stroke="#d97706" strokeWidth="1.5"/>
      
      {/* Hair */}
      <path d="M 40 25 Q 60 15 80 25 Q 75 20 60 18 Q 45 20 40 25" fill="#1f2937"/>
      
      {/* Eyes */}
      <circle cx="52" cy="36" r="2.5" fill="#1f2937"/>
      <circle cx="68" cy="36" r="2.5" fill="#1f2937"/>
      <circle cx="52.5" cy="35.5" r="0.8" fill="#ffffff"/>
      <circle cx="68.5" cy="35.5" r="0.8" fill="#ffffff"/>
      
      {/* Eyebrows */}
      <path d="M 48 32 Q 52 30 56 32" stroke="#1f2937" strokeWidth="1.5" fill="none"/>
      <path d="M 64 32 Q 68 30 72 32" stroke="#1f2937" strokeWidth="1.5" fill="none"/>
      
      {/* Nose */}
      <ellipse cx="60" cy="42" rx="1.5" ry="3" fill="#f59e0b"/>
      
      {/* Mouth */}
      <path d="M 56 48 Q 60 51 64 48" stroke="#1f2937" strokeWidth="2" fill="none"/>
      
      {/* Tracksuit details */}
      <line x1="60" y1="50" x2="60" y2="110" stroke="#15803d" strokeWidth="3"/>
      <circle cx="60" cy="60" r="2" fill="#ffffff"/>
      <circle cx="60" cy="70" r="2" fill="#ffffff"/>
      <circle cx="60" cy="80" r="2" fill="#ffffff"/>
      
      {/* Collar */}
      <path d="M 45 55 Q 60 50 75 55" stroke="#15803d" strokeWidth="2" fill="none"/>
      
      {/* Arms */}
      <ellipse cx="35" cy="70" rx="8" ry="20" fill="url(#tracksuit)" stroke="#15803d" strokeWidth="1.5"/>
      <ellipse cx="85" cy="70" rx="8" ry="20" fill="url(#tracksuit)" stroke="#15803d" strokeWidth="1.5"/>
      
      {/* Hands */}
      <circle cx="35" cy="88" r="5" fill="url(#face)" stroke="#d97706" strokeWidth="1"/>
      <circle cx="85" cy="88" r="5" fill="url(#face)" stroke="#d97706" strokeWidth="1"/>
    </svg>
  );

  return (
    <div className="text-center">
      <div className={`${sizeClasses[size]} mx-auto mb-2 relative border-3 border-squid-teal/50 rounded-lg overflow-hidden bg-squid-dark-light`} style={{borderRadius: '8px'}}>
        <SquidGamePlayerSVG />
        
        {/* Vote indicator */}
        {player.hasVoted && (
          <div className={`absolute -top-2 -right-2 w-6 h-6 rounded-full border-2 border-white ${
            player.vote === 'O' ? 'bg-green-400' : 'bg-squid-red'
          } flex items-center justify-center shadow-lg`}>
            <span className="text-white text-xs font-bold">{player.vote}</span>
          </div>
        )}
      </div>
      
      {/* Player info below avatar */}
      <div className="space-y-1">
        <div className="bg-squid-teal/20 border border-squid-teal/50 rounded px-2 py-1 mx-auto w-fit">
          <span className="text-squid-teal font-orbitron font-bold text-xs">
            #{String(player.playerNumber).padStart(3, '0')}
          </span>
        </div>
        <div className="text-xs text-gray-300 font-inter truncate max-w-[80px]">{player.name}</div>
      </div>
    </div>
  );
}
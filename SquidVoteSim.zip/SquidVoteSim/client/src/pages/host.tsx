import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import type { Session, InsertSession } from "@shared/schema";

export default function HostPage() {
  const [, setLocation] = useLocation();
  const [question, setQuestion] = useState("");
  const [optionO, setOptionO] = useState("YES");
  const [optionX, setOptionX] = useState("NO");
  const { toast } = useToast();

  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: InsertSession) => {
      const response = await apiRequest("POST", "/api/sessions", sessionData);
      return response.json() as Promise<Session>;
    },
    onSuccess: (session) => {
      const shareUrl = `${window.location.origin}/join/${session.id}`;
      
      // Store host ID in localStorage to identify this user as the host
      localStorage.setItem(`host_${session.id}`, session.hostId);
      
      navigator.clipboard.writeText(shareUrl).then(() => {
        toast({
          title: "Session Created!",
          description: `Session ID: ${session.id}. Share link copied to clipboard!`,
        });
      });

      setLocation(`/results/${session.id}`);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create session. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateSession = () => {
    if (!question.trim()) {
      toast({
        title: "Error",
        description: "Please enter a voting question",
        variant: "destructive",
      });
      return;
    }

    createSessionMutation.mutate({
      question: question.trim(),
      optionO: optionO.trim() || "YES",
      optionX: optionX.trim() || "NO",
      isActive: true,
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative bg-squid-dark">
      <div className="absolute inset-0 pink-glow"></div>
      <div className="absolute inset-0 bg-gradient-to-br from-squid-dark via-squid-dark-light to-squid-dark opacity-90"></div>
      
      <div className="relative z-10 max-w-2xl mx-auto px-6 text-center">
        <div className="mb-12">
          <h1 className="font-orbitron text-6xl md:text-8xl font-black text-squid-pink mb-4 animate-glow">
            SQUID GAME
          </h1>
          <h2 className="font-orbitron text-2xl md:text-3xl font-bold text-squid-teal mb-2">
            VOTING SYSTEM
          </h2>
          <div className="w-32 h-1 bg-squid-pink mx-auto"></div>
        </div>

        <div className="bg-squid-dark-light/80 backdrop-blur-sm border border-squid-pink/30 rounded-2xl p-8 md:p-12">
          <h3 className="font-orbitron text-xl font-bold mb-8 text-squid-teal">CREATE VOTING SESSION</h3>
          
          <div className="space-y-6">
            <div>
              <Label className="block text-sm font-medium mb-3 text-squid-pink">VOTING TOPIC</Label>
              <Input
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Enter your voting question..."
                className="w-full px-4 py-4 bg-squid-dark border-2 border-squid-teal/50 rounded-lg font-orbitron text-white placeholder-gray-400 focus:border-squid-teal focus:outline-none focus:ring-2 focus:ring-squid-teal/50"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="block text-sm font-medium mb-3 text-squid-pink">OPTION O</Label>
                <Input
                  value={optionO}
                  onChange={(e) => setOptionO(e.target.value)}
                  placeholder="YES / AGREE"
                  className="w-full px-3 py-3 bg-squid-dark border-2 border-squid-teal/50 rounded-lg font-orbitron text-white placeholder-gray-400 focus:border-squid-teal focus:outline-none"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium mb-3 text-squid-pink">OPTION X</Label>
                <Input
                  value={optionX}
                  onChange={(e) => setOptionX(e.target.value)}
                  placeholder="NO / DISAGREE"
                  className="w-full px-3 py-3 bg-squid-dark border-2 border-squid-teal/50 rounded-lg font-orbitron text-white placeholder-gray-400 focus:border-squid-teal focus:outline-none"
                />
              </div>
            </div>
          </div>

          <Button
            onClick={handleCreateSession}
            disabled={createSessionMutation.isPending}
            className="w-full mt-8 bg-squid-pink hover:bg-squid-pink-light text-white font-orbitron font-bold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-squid-pink/50"
          >
            {createSessionMutation.isPending ? "CREATING..." : "CREATE SESSION"}
          </Button>
        </div>
        
        {/* Attribution */}
        <div className="mt-16 text-center border-t border-squid-teal/20 pt-8">
          <p className="text-gray-400 text-sm font-inter">
            Made by <span className="text-squid-teal font-semibold">Yuvraj Singh</span>
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Check me out on{" "}
            <a 
              href="https://linktr.ee/curioboxys" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-squid-pink hover:text-squid-pink-light transition-colors underline"
            >
              https://linktr.ee/curioboxys
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

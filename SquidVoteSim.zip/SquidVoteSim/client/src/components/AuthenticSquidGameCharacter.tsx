import { Player } from "@shared/schema";

interface AuthenticSquidGameCharacterProps {
  player: Player;
  size?: "sm" | "md" | "lg";
}

export function AuthenticSquidGameCharacter({ player, size = "md" }: AuthenticSquidGameCharacterProps) {
  const sizeClasses = {
    sm: "w-12 h-12 text-xs",
    md: "w-16 h-16 text-sm", 
    lg: "w-20 h-20 text-base"
  };

  // Authentic Squid Game characters from the show
  const characters = [
    // Player 456 - Seong Gi-hun
    { name: "Gi-hun", skin: "#f4c2a1", hair: "#2c1810", eyes: "#1a1a1a", shirt: "#2d5a3d" },
    // Player 067 - Kang Sae-byeok  
    { name: "Sae-byeok", skin: "#f7d4b8", hair: "#0f0805", eyes: "#2c2c2c", shirt: "#3d7c52" },
    // Player 218 - Cho Sang-woo
    { name: "Sang-woo", skin: "#e8b892", hair: "#1a0f0a", eyes: "#1f1f1f", shirt: "#2a5233" },
    // Player 199 - Ali Abdul
    { name: "Ali", skin: "#d4a574", hair: "#0a0503", eyes: "#2a2a2a", shirt: "#4a8a5f" },
    // Player 001 - Oh Il-nam
    { name: "Il-nam", skin: "#f1c19e", hair: "#8a8a8a", eyes: "#3c3c3c", shirt: "#356b44" },
    // Player 212 - Han Mi-nyeo
    { name: "Mi-nyeo", skin: "#f5d0a8", hair: "#4a2c1a", eyes: "#262626", shirt: "#2f5f3f" },
    // Player 017 - Jang Deok-su
    { name: "Deok-su", skin: "#e2a373", hair: "#1c1008", eyes: "#1d1d1d", shirt: "#3a6e4a" },
    // Player 240 - Ji-yeong
    { name: "Ji-yeong", skin: "#f6d2aa", hair: "#2a1810", eyes: "#2e2e2e", shirt: "#337044" },
    // Player 101 - Jang Geum-ja
    { name: "Geum-ja", skin: "#ebb596", hair: "#6b6b6b", eyes: "#333333", shirt: "#2c5a3c" },
    // Player 119 - Byeong-gi
    { name: "Byeong-gi", skin: "#f0c4a0", hair: "#231611", eyes: "#252525", shirt: "#3f7a54" }
  ];

  const character = characters[player.playerNumber % characters.length];

  // Create authentic character portrait based on show designs
  const CharacterPortrait = () => (
    <div className="w-full h-full relative bg-gray-900 flex items-center justify-center rounded-lg overflow-hidden">
      {/* Character face and body */}
      <div className="relative w-14 h-16 transform scale-90">
        {/* Head */}
        <div 
          className="absolute top-0 left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full border-2 border-gray-700"
          style={{ backgroundColor: character.skin }}
        >
          {/* Hair - varies by character */}
          <div 
            className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-9 h-5 rounded-t-full border border-gray-800"
            style={{ backgroundColor: character.hair }}
          ></div>
          
          {/* Eyes - character specific */}
          <div 
            className="absolute top-2.5 left-1.5 w-1.5 h-1.5 rounded-full"
            style={{ backgroundColor: character.eyes }}
          ></div>
          <div 
            className="absolute top-2.5 right-1.5 w-1.5 h-1.5 rounded-full"
            style={{ backgroundColor: character.eyes }}
          ></div>
          
          {/* Eye highlights */}
          <div className="absolute top-2.5 left-2 w-0.5 h-0.5 bg-white rounded-full"></div>
          <div className="absolute top-2.5 right-2 w-0.5 h-0.5 bg-white rounded-full"></div>
          
          {/* Nose */}
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-1 h-1.5 bg-gray-400 rounded"></div>
          
          {/* Mouth */}
          <div className="absolute top-5.5 left-1/2 transform -translate-x-1/2 w-3 h-0.5 bg-red-900 rounded"></div>
        </div>
        
        {/* Body - Green tracksuit */}
        <div 
          className="absolute top-7 left-1/2 transform -translate-x-1/2 w-10 h-9 rounded-lg border-2 border-gray-800"
          style={{ backgroundColor: character.shirt }}
        >
          {/* Tracksuit zipper */}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-gray-900"></div>
          
          {/* Collar */}
          <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-7 h-2 bg-gray-800 rounded-t-lg"></div>
          
          {/* Buttons */}
          <div className="absolute top-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-white rounded-full"></div>
          <div className="absolute top-3 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-white rounded-full"></div>
          <div className="absolute top-5 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-white rounded-full"></div>
        </div>
        
        {/* Arms */}
        <div 
          className="absolute top-8 left-0 w-2.5 h-6 rounded-lg border border-gray-800"
          style={{ backgroundColor: character.shirt }}
        ></div>
        <div 
          className="absolute top-8 right-0 w-2.5 h-6 rounded-lg border border-gray-800"
          style={{ backgroundColor: character.shirt }}
        ></div>
        
        {/* Hands */}
        <div 
          className="absolute top-13 left-0 w-2.5 h-2.5 rounded-full border border-gray-700"
          style={{ backgroundColor: character.skin }}
        ></div>
        <div 
          className="absolute top-13 right-0 w-2.5 h-2.5 rounded-full border border-gray-700"
          style={{ backgroundColor: character.skin }}
        ></div>
      </div>
      
      {/* Realistic shading overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-black/30"></div>
      
      {/* Character ID number on tracksuit */}
      <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 bg-white/90 border border-gray-600 rounded px-1 py-0.5">
        <span className="text-black font-bold text-xs">
          {String(player.playerNumber).padStart(3, '0')}
        </span>
      </div>
    </div>
  );

  return (
    <div className="text-center">
      <div className={`${sizeClasses[size]} mx-auto mb-2 relative border-2 border-squid-teal/30 rounded-lg overflow-hidden shadow-xl`}>
        <CharacterPortrait />
        
        {/* Vote indicator */}
        {player.hasVoted && (
          <div className={`absolute -top-2 -right-2 w-6 h-6 rounded-full border-2 border-white ${
            player.vote === 'O' ? 'bg-green-400' : 'bg-squid-red'
          } flex items-center justify-center shadow-lg z-10`}>
            <span className="text-white text-xs font-bold">{player.vote}</span>
          </div>
        )}
      </div>
      
      {/* Player info */}
      <div className="space-y-1">
        <div className="bg-squid-teal/20 border border-squid-teal/50 rounded px-2 py-1 mx-auto w-fit">
          <span className="text-squid-teal font-orbitron font-bold text-xs">
            #{String(player.playerNumber).padStart(3, '0')}
          </span>
        </div>
        <div className="text-xs text-gray-300 font-inter truncate max-w-[80px]">{player.name}</div>
        <div className="text-xs text-blue-400 font-orbitron">{character.name}</div>
      </div>
    </div>
  );
}
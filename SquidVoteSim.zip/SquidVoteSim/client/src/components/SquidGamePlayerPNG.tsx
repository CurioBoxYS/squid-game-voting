import { Player } from "@shared/schema";

interface SquidGamePlayerPNGProps {
  player: Player;
  size?: "sm" | "md" | "lg";
}

export function SquidGamePlayerPNG({ player, size = "md" }: SquidGamePlayerPNGProps) {
  const sizeClasses = {
    sm: "w-12 h-12 text-xs",
    md: "w-16 h-16 text-sm", 
    lg: "w-20 h-20 text-base"
  };

  // Generate a unique character appearance based on player number
  const getCharacterVariation = () => {
    const variations = [
      { skin: '#f4c2a1', hair: '#2c1810', shirt: '#2d5a3d' },
      { skin: '#e8b892', hair: '#1a0f0a', shirt: '#3d7c52' },
      { skin: '#f7d4b8', hair: '#3d2817', shirt: '#2a5233' },
      { skin: '#e2a373', hair: '#0f0805', shirt: '#4a8a5f' },
      { skin: '#f1c19e', hair: '#2f1f14', shirt: '#356b44' }
    ];
    return variations[player.playerNumber % variations.length];
  };

  const char = getCharacterVariation();

  // Create PNG-style pixelated/realistic Squid Game character
  const PlayerImage = () => (
    <div className="w-full h-full relative bg-gray-800 flex items-center justify-center">
      {/* Character portrait in PNG style */}
      <div className="relative w-12 h-14 transform scale-110">
        {/* Head/Face */}
        <div 
          className="absolute top-1 left-1/2 transform -translate-x-1/2 w-7 h-7 rounded-full border-2 border-gray-600"
          style={{ backgroundColor: char.skin }}
        >
          {/* Hair */}
          <div 
            className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-8 h-4 rounded-t-full"
            style={{ backgroundColor: char.hair }}
          ></div>
          
          {/* Eyes */}
          <div className="absolute top-2 left-1.5 w-1 h-1 bg-black rounded-full"></div>
          <div className="absolute top-2 right-1.5 w-1 h-1 bg-black rounded-full"></div>
          
          {/* Nose */}
          <div className="absolute top-3 left-1/2 transform -translate-x-1/2 w-0.5 h-1 bg-gray-400 rounded"></div>
          
          {/* Mouth */}
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-2 h-0.5 bg-red-800 rounded"></div>
        </div>
        
        {/* Body - Green tracksuit */}
        <div 
          className="absolute top-7 left-1/2 transform -translate-x-1/2 w-9 h-7 rounded border-2 border-gray-700"
          style={{ backgroundColor: char.shirt }}
        >
          {/* Tracksuit zipper line */}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-gray-800"></div>
          
          {/* Collar */}
          <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-6 h-2 bg-gray-700 rounded-t"></div>
          
          {/* Buttons */}
          <div className="absolute top-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-white rounded-full"></div>
          <div className="absolute top-3 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-white rounded-full"></div>
        </div>
        
        {/* Arms */}
        <div 
          className="absolute top-8 left-0 w-2 h-5 rounded border border-gray-700"
          style={{ backgroundColor: char.shirt }}
        ></div>
        <div 
          className="absolute top-8 right-0 w-2 h-5 rounded border border-gray-700"
          style={{ backgroundColor: char.shirt }}
        ></div>
        
        {/* Hands */}
        <div 
          className="absolute top-12 left-0 w-2 h-2 rounded-full border border-gray-600"
          style={{ backgroundColor: char.skin }}
        ></div>
        <div 
          className="absolute top-12 right-0 w-2 h-2 rounded-full border border-gray-600"
          style={{ backgroundColor: char.skin }}
        ></div>
      </div>
      
      {/* PNG-style pixelation effect */}
      <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: `linear-gradient(90deg, transparent 50%, rgba(0,0,0,0.1) 50%), linear-gradient(transparent 50%, rgba(0,0,0,0.1) 50%)`,
        backgroundSize: '2px 2px'
      }}></div>
    </div>
  );

  return (
    <div className="text-center">
      <div className={`${sizeClasses[size]} mx-auto mb-2 relative border-2 border-squid-teal/30 rounded-lg overflow-hidden shadow-lg`}>
        <PlayerImage />
        
        {/* Vote indicator */}
        {player.hasVoted && (
          <div className={`absolute -top-2 -right-2 w-6 h-6 rounded-full border-2 border-white ${
            player.vote === 'O' ? 'bg-green-400' : 'bg-squid-red'
          } flex items-center justify-center shadow-lg`}>
            <span className="text-white text-xs font-bold">{player.vote}</span>
          </div>
        )}
      </div>
      
      {/* Player info below avatar */}
      <div className="space-y-1">
        <div className="bg-squid-teal/20 border border-squid-teal/50 rounded px-2 py-1 mx-auto w-fit">
          <span className="text-squid-teal font-orbitron font-bold text-xs">
            #{String(player.playerNumber).padStart(3, '0')}
          </span>
        </div>
        <div className="text-xs text-gray-300 font-inter truncate max-w-[80px]">{player.name}</div>
      </div>
    </div>
  );
}
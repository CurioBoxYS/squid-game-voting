import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type { Session, Player } from "@shared/schema";

export default function VotePage() {
  const { sessionId, playerId } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: session } = useQuery<Session>({
    queryKey: ["/api/sessions", sessionId],
    enabled: !!sessionId,
  });

  const { data: player } = useQuery<Player>({
    queryKey: ["/api/players", playerId],
    enabled: !!playerId,
  });

  const { data: votes = { O: 0, X: 0, players: [] } } = useQuery<{ O: number; X: number; players: Player[] }>({
    queryKey: ["/api/sessions", sessionId, "votes"],
    enabled: !!sessionId,
    refetchInterval: 1000, // Real-time updates
  });

  const voteMutation = useMutation({
    mutationFn: async (vote: 'O' | 'X') => {
      const response = await apiRequest("POST", `/api/players/${playerId}/vote`, { vote });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Vote Cast!",
        description: "Your vote has been recorded.",
      });
      // Invalidate queries to update counts
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId, "votes"] });
      // Redirect to results after a short delay
      setTimeout(() => {
        setLocation(`/results/${sessionId}`);
      }, 1500);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to cast vote. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleVote = (choice: 'O' | 'X') => {
    if (player?.hasVoted) {
      toast({
        title: "Already Voted",
        description: "You have already cast your vote!",
        variant: "destructive",
      });
      return;
    }
    
    if (session?.isVotingEnded) {
      toast({
        title: "Voting Ended",
        description: "The host has ended this voting session.",
        variant: "destructive",
      });
      return;
    }
    
    voteMutation.mutate(choice);
  };

  if (!session || !player) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-squid-dark">
        <div className="text-squid-teal font-orbitron text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center relative bg-squid-dark">
      <div className="absolute inset-0 bg-gradient-to-b from-squid-dark-light to-squid-dark"></div>
      
      <div className="relative z-10 max-w-4xl mx-auto px-6">
        {/* Machine Display Screen */}
        <div className="bg-squid-teal/20 border-4 border-squid-teal rounded-3xl p-8 mb-8">
          <div className="bg-squid-dark rounded-2xl p-6 text-center">
            <h2 className="font-orbitron text-2xl md:text-3xl font-bold text-squid-teal mb-4">
              {session.question}
            </h2>
            <div className="flex justify-center items-center space-x-8 mt-6">
              <div className="text-center">
                <div className="text-6xl font-orbitron font-black text-green-400">{votes.O}</div>
                <div className="text-squid-teal font-orbitron mt-2">{session.optionO}</div>
              </div>
              <div className="text-6xl text-squid-pink">|</div>
              <div className="text-center">
                <div className="text-6xl font-orbitron font-black text-squid-red">{votes.X}</div>
                <div className="text-squid-teal font-orbitron mt-2">{session.optionX}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Voting Buttons */}
        {/* Voting Status Message */}
        {session?.isVotingEnded && (
          <div className="max-w-2xl mx-auto mb-8">
            <div className="bg-squid-red/20 border-2 border-squid-red rounded-lg p-6 text-center">
              <h3 className="font-orbitron text-xl font-bold text-squid-red mb-2">VOTING HAS ENDED</h3>
              <p className="text-white">The host has closed this voting session. Check the results page for final tallies.</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-8 max-w-2xl mx-auto">
          <Button
            onClick={() => handleVote('O')}
            disabled={player.hasVoted || voteMutation.isPending || session?.isVotingEnded}
            className="machine-button group h-48 bg-green-500 hover:bg-green-400 rounded-full flex items-center justify-center border-8 border-squid-dark shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <span className="font-orbitron text-8xl font-black text-white group-hover:scale-110 transition-transform">O</span>
          </Button>
          
          <Button
            onClick={() => handleVote('X')}
            disabled={player.hasVoted || voteMutation.isPending || session?.isVotingEnded}
            className="machine-button group h-48 bg-squid-red hover:bg-red-500 rounded-full flex items-center justify-center border-8 border-squid-dark shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <span className="font-orbitron text-8xl font-black text-white group-hover:scale-110 transition-transform">X</span>
          </Button>
        </div>

        {/* Player Info */}
        <div className="text-center mt-8">
          <div className="inline-flex items-center space-x-4 bg-squid-dark-light/80 rounded-full px-6 py-3">
            <div className="w-12 h-12 bg-squid-green rounded-full flex items-center justify-center">
              <span className="text-white font-orbitron font-bold">{String(player.playerNumber).padStart(3, '0')}</span>
            </div>
            <span className="text-squid-teal font-orbitron font-bold">{player.name}</span>
            {player.hasVoted && (
              <span className="text-squid-pink font-orbitron text-sm">VOTED</span>
            )}
          </div>
        </div>

        <div className="text-center mt-6">
          <Button 
            onClick={() => setLocation(`/results/${sessionId}`)}
            variant="outline"
            className="border-squid-teal text-squid-teal hover:bg-squid-teal hover:text-squid-dark"
          >
            VIEW RESULTS
          </Button>
        </div>
        
        {/* Attribution */}
        <div className="mt-16 text-center border-t border-squid-teal/20 pt-8">
          <p className="text-gray-400 text-sm font-inter">
            Made by <span className="text-squid-teal font-semibold">Yuvraj Singh</span>
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Check me out on{" "}
            <a 
              href="https://linktr.ee/curioboxys" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-squid-pink hover:text-squid-pink-light transition-colors underline"
            >
              https://linktr.ee/curioboxys
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

# Squid Game Voting Simulator

A real-time voting application built with React and Express, featuring authentic Squid Game character avatars and voting machine interface.

## Features

- **Host Sessions**: Create voting sessions with custom questions and O/X options
- **Player Registration**: Join sessions with unique player numbers and authentic character avatars
- **Real-time Voting**: Interactive voting machine interface matching Squid Game aesthetic
- **Results Visualization**: Dormitory-style layout showing voters divided by their choices
- **Character Avatars**: Authentic portraits based on main Squid Game characters (Gi-hun, Sae-byeok, Ali, etc.)
- **Host Controls**: Only session creators can end voting and reset votes
- **Responsive Design**: Works on desktop and mobile devices

## Tech Stack

- **Frontend**: React + TypeScript, Vite, TailwindCSS, Wouter (routing)
- **Backend**: Express.js + TypeScript, in-memory storage for development
- **UI Components**: Shadcn/ui, Radix UI primitives
- **State Management**: TanStack Query (React Query)
- **Form Handling**: React Hook Form with Zod validation

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd squid-game-voting
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser to `http://localhost:5000`

### Usage

1. **Create a Session**: Enter a voting question and customize O/X options
2. **Share the Link**: Copy the generated link to invite players
3. **Players Join**: Each player gets a unique number and character avatar
4. **Vote**: Players use the authentic Squid Game voting machine interface
5. **View Results**: See real-time results with character portraits divided by votes
6. **Host Controls**: End voting or reset votes (host only)

## Project Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── pages/         # Route components
│   │   ├── hooks/         # Custom hooks
│   │   └── lib/           # Utilities
├── server/                # Express backend
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   └── storage.ts        # Data storage layer
├── shared/               # Shared types and schemas
└── components.json       # Shadcn/ui configuration
```

## Character System

Players are assigned authentic Squid Game character avatars:
- Gi-hun (Player 456)
- Sae-byeok (Player 067)
- Sang-woo (Player 218)
- Ali Abdul (Player 199)
- Il-nam (Player 001)
- Mi-nyeo (Player 212)
- Deok-su (Player 017)
- Ji-yeong (Player 240)
- And more!

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Connect your GitHub repository to Vercel
3. Vercel will automatically detect the build settings
4. Your app will be deployed with a public URL

### Other Platforms

- **Netlify**: Similar to Vercel, free tier available
- **Railway**: Free tier with monthly credits
- **Render**: Free web services for hobby projects

## Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build locally

### Environment Variables

For production deployment, you may need to configure:
- `NODE_ENV=production`
- Database connection strings (if switching from in-memory storage)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is for educational and entertainment purposes.

## Credits

**Created by Yuvraj Singh**  
Check me out: [https://linktr.ee/curioboxys](https://linktr.ee/curioboxys)

---

*Inspired by the Netflix series "Squid Game"*
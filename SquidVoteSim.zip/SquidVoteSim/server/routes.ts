import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSessionSchema, insertPlayerSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create voting session
  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = insertSessionSchema.parse(req.body);
      const session = await storage.createSession(sessionData);
      res.json(session);
    } catch (error) {
      console.error("Error creating session:", error);
      res.status(400).json({ error: "Invalid session data" });
    }
  });

  // Get session by ID
  app.get("/api/sessions/:id", async (req, res) => {
    try {
      const session = await storage.getSession(req.params.id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      console.error("Error fetching session:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Add player to session
  app.post("/api/sessions/:sessionId/players", async (req, res) => {
    try {
      const playerData = insertPlayerSchema.parse({
        ...req.body,
        sessionId: req.params.sessionId,
      });
      
      const session = await storage.getSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }

      const player = await storage.addPlayer(playerData);
      res.json(player);
    } catch (error) {
      console.error("Error adding player:", error);
      res.status(400).json({ error: "Invalid player data" });
    }
  });

  // Get session players
  app.get("/api/sessions/:sessionId/players", async (req, res) => {
    try {
      const players = await storage.getSessionPlayers(req.params.sessionId);
      res.json(players);
    } catch (error) {
      console.error("Error fetching players:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get player by ID
  app.get("/api/players/:playerId", async (req, res) => {
    try {
      const player = await storage.getPlayer(req.params.playerId);
      if (!player) {
        return res.status(404).json({ error: "Player not found" });
      }
      res.json(player);
    } catch (error) {
      console.error("Error fetching player:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Cast vote
  app.post("/api/players/:playerId/vote", async (req, res) => {
    try {
      const { vote } = req.body;
      if (vote !== 'O' && vote !== 'X') {
        return res.status(400).json({ error: "Invalid vote. Must be 'O' or 'X'" });
      }

      const player = await storage.getPlayer(req.params.playerId);
      if (!player) {
        return res.status(404).json({ error: "Player not found" });
      }

      if (player.hasVoted) {
        return res.status(400).json({ error: "Player has already voted" });
      }

      const updatedPlayer = await storage.updatePlayerVote(req.params.playerId, vote);
      res.json(updatedPlayer);
    } catch (error) {
      console.error("Error casting vote:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get session votes/results
  app.get("/api/sessions/:sessionId/votes", async (req, res) => {
    try {
      const results = await storage.getSessionVotes(req.params.sessionId);
      res.json(results);
    } catch (error) {
      console.error("Error fetching votes:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Reset session votes
  app.post("/api/sessions/:sessionId/reset", async (req, res) => {
    try {
      await storage.resetSessionVotes(req.params.sessionId);
      res.json({ message: "Votes reset successfully" });
    } catch (error) {
      console.error("Error resetting votes:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // End session voting
  app.post("/api/sessions/:sessionId/end", async (req, res) => {
    try {
      const session = await storage.endSessionVoting(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json({ message: "Voting ended successfully", session });
    } catch (error) {
      console.error("Error ending voting:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

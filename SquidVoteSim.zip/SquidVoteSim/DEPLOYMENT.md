# Deployment Guide

## GitHub Export & Free Deployment

### Step 1: Export to GitHub

1. **Create a new GitHub repository**
   - Go to [GitHub.com](https://github.com) and click "New Repository"
   - Name it `squid-game-voting` (or any name you prefer)
   - Make it public (required for free deployments)
   - Don't initialize with README (we have one)

2. **Download your project files**
   - In Replit, click the three dots menu
   - Select "Download as zip"
   - Extract the zip file on your computer

3. **Upload to GitHub**
   - In your new GitHub repo, click "uploading an existing file"
   - Drag and drop all your project files (except .replit and replit.nix)
   - Commit the files

### Step 2: Deploy for Free

## Option A: Vercel (Recommended - Easiest)

1. Go to [vercel.com](https://vercel.com) and sign up with GitHub
2. Click "New Project" 
3. Import your GitHub repository
4. Vercel will auto-detect the settings
5. Click "Deploy"
6. Your app will be live at `your-project.vercel.app`

**Build Settings (Auto-detected):**
- Framework Preset: Vite
- Build Command: `npm run build`
- Output Directory: `client/dist`

## Option B: Netlify

1. Go to [netlify.com](https://netlify.com) and sign up with GitHub
2. Click "New site from Git"
3. Choose your repository
4. Set build settings:
   - Build command: `npm run build`
   - Publish directory: `client/dist`
5. Click "Deploy site"

## Option C: Railway

1. Go to [railway.app](https://railway.app) and sign up with GitHub
2. Click "New Project" → "Deploy from GitHub repo"
3. Select your repository
4. Railway will auto-deploy (no configuration needed)
5. Your app will be live on a railway.app domain

## Option D: Render

1. Go to [render.com](https://render.com) and sign up with GitHub
2. Click "New" → "Web Service"
3. Connect your repository
4. Settings:
   - Environment: `Node`
   - Build Command: `npm install && npm run build`
   - Start Command: `npm start`

### Environment Variables

For production deployment, you may need to set:
```
NODE_ENV=production
```

### Custom Domain (Optional)

All platforms offer custom domain support:
- **Vercel**: Project Settings → Domains
- **Netlify**: Site Settings → Domain Management  
- **Railway**: Project Settings → Domains
- **Render**: Settings → Custom Domains

### Expected Costs

All mentioned platforms offer generous free tiers:
- **Vercel**: 100GB bandwidth, unlimited sites
- **Netlify**: 100GB bandwidth, 300 build minutes
- **Railway**: $5 monthly credits (usually enough for small apps)
- **Render**: 750 hours/month free tier

Your Squid Game voting app should run comfortably within all free limits!

### Troubleshooting

**Build Errors**: Make sure all dependencies are in package.json
**404 Errors**: Check that routing is configured for single-page apps
**API Errors**: Verify environment variables are set correctly

### Support

Need help? Each platform has excellent documentation:
- [Vercel Docs](https://vercel.com/docs)
- [Netlify Docs](https://docs.netlify.com)
- [Railway Docs](https://docs.railway.app)
- [Render Docs](https://render.com/docs)
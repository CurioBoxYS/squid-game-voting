import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { AuthenticSquidGameCharacter } from "@/components/AuthenticSquidGameCharacter";
import type { Session, Player } from "@shared/schema";

export default function ResultsPage() {
  const { sessionId } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Check if current user is the host of this session
  const isHost = sessionId && localStorage.getItem(`host_${sessionId}`) !== null;

  const { data: session } = useQuery<Session>({
    queryKey: ["/api/sessions", sessionId],
    enabled: !!sessionId,
  });

  const { data: votes = { O: 0, X: 0, players: [] } } = useQuery<{ O: number; X: number; players: Player[] }>({
    queryKey: ["/api/sessions", sessionId, "votes"],
    enabled: !!sessionId,
    refetchInterval: 2000, // Real-time updates
  });

  const resetVotesMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/sessions/${sessionId}/reset`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Votes Reset",
        description: "All votes have been cleared.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId, "votes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reset votes.",
        variant: "destructive",
      });
    },
  });

  const endVotingMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/sessions/${sessionId}/end`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Voting Ended",
        description: "The voting session has been closed.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId] });
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId, "votes"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to end voting.",
        variant: "destructive",
      });
    },
  });

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-squid-dark">
        <div className="text-squid-teal font-orbitron text-xl">Loading...</div>
      </div>
    );
  }

  const oVoters = votes.players.filter((p: Player) => p.vote === 'O');
  const xVoters = votes.players.filter((p: Player) => p.vote === 'X');

  const shareUrl = `${window.location.origin}/join/${sessionId}`;

  const copyShareLink = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      toast({
        title: "Link Copied!",
        description: "Share link copied to clipboard.",
      });
    });
  };

  return (
    <div className="min-h-screen relative bg-squid-dark">
      <div className="absolute inset-0 results-grid"></div>
      
      {/* Dramatic lighting effects */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-squid-pink/20 rounded-full blur-3xl animate-pulse-slow"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-squid-pink/20 rounded-full blur-3xl animate-pulse-slow"></div>
      
      <div className="relative z-10 py-12 px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="font-orbitron text-4xl md:text-6xl font-black text-squid-pink mb-4">
            VOTING RESULTS
          </h1>
          <div className="max-w-4xl mx-auto">
            <h2 className="text-xl md:text-2xl text-squid-teal font-orbitron font-bold mb-6">
              {session.question}
            </h2>
            <div className="flex justify-center items-center space-x-12">
              <div className="text-center">
                <div className="text-5xl md:text-7xl font-orbitron font-black text-green-400">{votes.O}</div>
                <div className="text-squid-teal font-orbitron text-xl mt-2">{session.optionO}</div>
              </div>
              <div className="text-5xl text-squid-pink">VS</div>
              <div className="text-center">
                <div className="text-5xl md:text-7xl font-orbitron font-black text-squid-red">{votes.X}</div>
                <div className="text-squid-teal font-orbitron text-xl mt-2">{session.optionX}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Share Link */}
        <div className="text-center mb-8">
          <div className="max-w-2xl mx-auto bg-squid-dark-light/80 rounded-lg p-4">
            <p className="text-squid-teal font-orbitron text-sm mb-2">SHARE VOTING LINK:</p>
            <div className="flex items-center gap-2">
              <input 
                value={shareUrl}
                readOnly
                className="flex-1 bg-squid-dark border border-squid-teal/50 rounded px-3 py-2 text-white font-mono text-sm"
              />
              <Button 
                onClick={copyShareLink}
                className="bg-squid-teal hover:bg-cyan-400 text-squid-dark font-orbitron font-bold"
              >
                COPY
              </Button>
            </div>
          </div>
        </div>

        {/* Voting Status Banner */}
        {session.isVotingEnded && (
          <div className="max-w-4xl mx-auto mb-8">
            <div className="bg-squid-red/20 border-2 border-squid-red rounded-lg p-6 text-center">
              <h3 className="font-orbitron text-2xl font-bold text-squid-red mb-2">VOTING SESSION ENDED</h3>
              <p className="text-white">Final results are displayed below. No more votes will be accepted.</p>
            </div>
          </div>
        )}

        {/* Players Division */}
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            {/* O Side Players */}
            <div className="text-center">
              <h3 className="font-orbitron text-2xl font-bold text-green-400 mb-8">
                {session.optionO} VOTERS ({oVoters.length})
              </h3>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
                {oVoters.map((player: Player) => (
                  <AuthenticSquidGameCharacter key={player.id} player={player} />
                ))}
                {oVoters.length === 0 && (
                  <div className="col-span-full text-gray-500 font-orbitron">No voters yet</div>
                )}
              </div>
            </div>

            {/* X Side Players */}
            <div className="text-center">
              <h3 className="font-orbitron text-2xl font-bold text-squid-red mb-8">
                {session.optionX} VOTERS ({xVoters.length})
              </h3>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
                {xVoters.map((player: Player) => (
                  <AuthenticSquidGameCharacter key={player.id} player={player} />
                ))}
                {xVoters.length === 0 && (
                  <div className="col-span-full text-gray-500 font-orbitron">No voters yet</div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Control Buttons */}
        <div className="text-center mt-12 space-y-4">
          <div className="space-x-4">
            <Button 
              onClick={() => setLocation("/")}
              className="bg-squid-pink hover:bg-squid-pink-light text-white font-orbitron font-bold py-3 px-8 rounded-lg transition-all duration-300"
            >
              NEW SESSION
            </Button>
            {!session.isVotingEnded && isHost && (
              <Button 
                onClick={() => endVotingMutation.mutate()}
                disabled={endVotingMutation.isPending}
                className="bg-squid-red hover:bg-red-500 text-white font-orbitron font-bold py-3 px-8 rounded-lg transition-all duration-300"
              >
                {endVotingMutation.isPending ? "ENDING..." : "END VOTING"}
              </Button>
            )}
          </div>
          {isHost && (
            <div className="space-x-4">
              <Button 
                onClick={() => resetVotesMutation.mutate()}
                disabled={resetVotesMutation.isPending}
                className="bg-squid-teal hover:bg-cyan-400 text-squid-dark font-orbitron font-bold py-3 px-8 rounded-lg transition-all duration-300"
              >
                {resetVotesMutation.isPending ? "RESETTING..." : "RESET VOTES"}
              </Button>
            </div>
          )}
        </div>
        
        {/* Attribution */}
        <div className="mt-16 text-center border-t border-squid-teal/20 pt-8">
          <p className="text-gray-400 text-sm font-inter">
            Made by <span className="text-squid-teal font-semibold">Yuvraj Singh</span>
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Check me out on{" "}
            <a 
              href="https://linktr.ee/curioboxys" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-squid-pink hover:text-squid-pink-light transition-colors underline"
            >
              https://linktr.ee/curioboxys
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}



# Overview

This is a Squid Game-themed real-time voting application built with React frontend and Express backend. The app allows hosts to create voting sessions with custom questions and O/X options, while participants can join sessions and cast votes using an authentic Squid Game voting machine interface. The system provides real-time updates with Squid Game character avatars and dormitory-style results visualization.

## Recent Changes (August 16, 2025)
- ✅ Added host voting session end functionality 
- ✅ Implemented authentic Squid Game character avatars based on main show characters
- ✅ Added host-only controls (only session creators can end voting/reset votes)
- ✅ Enhanced player visualization with vote indicators
- ✅ Added attribution footer with creator links
- ✅ Character names displayed in blue for better visibility
- ✅ Fixed all API endpoints and TypeScript type issues

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing with pages for hosting, joining, voting, and results
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful API with endpoints for session management, player operations, and voting
- **Development Storage**: In-memory storage implementation for rapid prototyping
- **Session Management**: UUID-based session IDs with automatic player numbering
- **Real-time Updates**: Polling-based approach using React Query's refetch intervals

## Data Storage Solutions
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Schema Design**: Two main entities - sessions and players with proper relationships
- **Migration System**: Drizzle Kit for database migrations and schema management
- **Development Mode**: MemStorage class provides in-memory data persistence for development

## Authentication and Authorization
- **Session-based**: No user authentication required - sessions are identified by shareable IDs
- **Access Control**: Session creators can reset votes, players can only vote once per session
- **Player Management**: Automatic player numbering and vote tracking

## External Dependencies
- **Database**: PostgreSQL with Neon Database serverless driver
- **UI Framework**: Radix UI for accessible component primitives
- **Development Tools**: Replit integration with error overlay and cartographer plugins
- **Build System**: ESBuild for production builds with Node.js platform targeting
- **Validation**: Zod for runtime type checking and schema validation
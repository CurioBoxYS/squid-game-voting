import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey(),
  hostId: varchar("host_id").notNull(), // Track session creator
  question: text("question").notNull(),
  optionO: text("option_o").notNull().default("YES"),
  optionX: text("option_x").notNull().default("NO"),
  isActive: boolean("is_active").notNull().default(true),
  isVotingEnded: boolean("is_voting_ended").notNull().default(false),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const players = pgTable("players", {
  id: varchar("id").primaryKey(),
  sessionId: varchar("session_id").notNull(),
  name: text("name").notNull(),
  playerNumber: integer("player_number").notNull(),
  hasVoted: boolean("has_voted").notNull().default(false),
  vote: varchar("vote", { length: 1 }), // 'O' or 'X'
  joinedAt: timestamp("joined_at").default(sql`now()`),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  hostId: true,
  createdAt: true,
});

export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
  playerNumber: true,
  hasVoted: true,
  vote: true,
  joinedAt: true,
});

export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Player = typeof players.$inferSelect;

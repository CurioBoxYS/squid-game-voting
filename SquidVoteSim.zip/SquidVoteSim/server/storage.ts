import { type Session, type InsertSession, type Player, type InsertPlayer } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createSession(session: InsertSession): Promise<Session>;
  getSession(id: string): Promise<Session | undefined>;
  getSessionPlayers(sessionId: string): Promise<Player[]>;
  addPlayer(player: InsertPlayer): Promise<Player>;
  getPlayer(id: string): Promise<Player | undefined>;
  updatePlayerVote(playerId: string, vote: 'O' | 'X'): Promise<Player | undefined>;
  getSessionVotes(sessionId: string): Promise<{ O: number; X: number; players: Player[] }>;
  resetSessionVotes(sessionId: string): Promise<void>;
  endSessionVoting(sessionId: string): Promise<Session | undefined>;
}

export class MemStorage implements IStorage {
  private sessions: Map<string, Session>;
  private players: Map<string, Player>;

  constructor() {
    this.sessions = new Map();
    this.players = new Map();
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = randomUUID().slice(0, 8).toUpperCase();
    const hostId = randomUUID(); // Generate unique host ID
    const session: Session = {
      id,
      hostId,
      question: insertSession.question,
      optionO: insertSession.optionO || "YES",
      optionX: insertSession.optionX || "NO", 
      isActive: insertSession.isActive !== undefined ? insertSession.isActive : true,
      isVotingEnded: false,
      createdAt: new Date(),
    };
    this.sessions.set(id, session);
    // Store hostId in browser localStorage for host identification
    return { ...session, hostId };
  }

  async getSession(id: string): Promise<Session | undefined> {
    return this.sessions.get(id);
  }

  async getSessionPlayers(sessionId: string): Promise<Player[]> {
    return Array.from(this.players.values())
      .filter(player => player.sessionId === sessionId)
      .sort((a, b) => a.playerNumber - b.playerNumber);
  }

  async addPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const id = randomUUID();
    const sessionPlayers = await this.getSessionPlayers(insertPlayer.sessionId);
    const playerNumber = sessionPlayers.length + 1;
    
    const player: Player = {
      ...insertPlayer,
      id,
      playerNumber,
      hasVoted: false,
      vote: null,
      joinedAt: new Date(),
    };
    
    this.players.set(id, player);
    return player;
  }

  async getPlayer(id: string): Promise<Player | undefined> {
    return this.players.get(id);
  }

  async updatePlayerVote(playerId: string, vote: 'O' | 'X'): Promise<Player | undefined> {
    const player = this.players.get(playerId);
    if (!player) return undefined;

    const updatedPlayer: Player = {
      ...player,
      hasVoted: true,
      vote,
    };
    
    this.players.set(playerId, updatedPlayer);
    return updatedPlayer;
  }

  async getSessionVotes(sessionId: string): Promise<{ O: number; X: number; players: Player[] }> {
    const players = await this.getSessionPlayers(sessionId);
    const votedPlayers = players.filter(p => p.hasVoted);
    
    const oVotes = votedPlayers.filter(p => p.vote === 'O').length;
    const xVotes = votedPlayers.filter(p => p.vote === 'X').length;
    
    return { O: oVotes, X: xVotes, players: votedPlayers };
  }

  async resetSessionVotes(sessionId: string): Promise<void> {
    const players = await this.getSessionPlayers(sessionId);
    players.forEach(player => {
      const resetPlayer: Player = {
        ...player,
        hasVoted: false,
        vote: null,
      };
      this.players.set(player.id, resetPlayer);
    });
  }

  async endSessionVoting(sessionId: string): Promise<Session | undefined> {
    const session = this.sessions.get(sessionId);
    if (!session) return undefined;

    const updatedSession: Session = {
      ...session,
      isVotingEnded: true,
    };
    
    this.sessions.set(sessionId, updatedSession);
    return updatedSession;
  }
}

export const storage = new MemStorage();
